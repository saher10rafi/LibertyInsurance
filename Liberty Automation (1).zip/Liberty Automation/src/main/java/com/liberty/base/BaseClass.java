package com.liberty.base;

import java.io.FileInputStream;
import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;

public class BaseClass {
	public static WebDriver driver;
	public static Properties prop;
	public static Logger log;
	public static ExtentTest logger;
	public static ExtentReports report;

	public static WebDriver initializeDriver() {
		prop = new Properties();
		FileInputStream fis;
		try {
			fis = new FileInputStream(System.getProperty("user.dir") + "\\externalFiles\\config.properties");
			prop.load(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Get Browser Name
		String browserName = prop.getProperty("browser");
		System.out.println(browserName);

		if (browserName.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver",
					System.getProperty("user.dir") + "\\drivers\\chromedriver.exe");
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--disable-notifications");
			driver = new ChromeDriver(chromeOptions);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		}

		else if (browserName.equals("edge")) {
			System.setProperty("webdriver.edge.driver", System.getProperty("user.dir") + "\\drivers\\edgedriver.exe");
			driver = new EdgeDriver();
		} else if (browserName.equals("firefox")) {
			// Add FireFox Code
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		return driver;
	}

	/*
	 * Method to click on element
	 */
	public static void clickOn(By objectPath) {
		try {
			log.debug("Clicking on object: " + objectPath);
			new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(objectPath));
			driver.findElement(objectPath).click();
			log.info("Clicked on object: " + objectPath);
		} catch (Exception e) {
			reportFail("Unable to click on object: " + objectPath + ", got exception: " + e.getMessage());
		}

	}

	/*
	 * Method to send text to element
	 */
	public static void sendText(By objectPath, String text) {
		try {
			log.debug("Sending text \"" + text + "\" to object: " + objectPath);
			new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated(objectPath));
			driver.findElement(objectPath).sendKeys(text);
			log.info("Sent text \"" + text + "\" to object: " + objectPath);
		} catch (Exception e) {
			reportFail("Unable to send text \"" + text + "\" to object: " + objectPath);
		}

	}

	/*
	 * Method to get current page title
	 */
	public static String getTitle() {
		waitForPageLoad();
		return driver.getTitle();
	}

	/*
	 * Method to validate page title
	 */
	public static void validatePageTitle(String expectedTitle) {
		waitForPageLoad();
		try {
			new WebDriverWait(driver, 60).until(ExpectedConditions.titleIs(expectedTitle));
			String actualTitle = getTitle();
			Assert.assertEquals(actualTitle, expectedTitle);
			logger.pass("Actual title matches expected title");
			log.info("Actual title matches expected title");
		} catch (Exception e) {
			reportFail("Actual title '" + getTitle() + "' does not match expected title '" + expectedTitle + "'");
		}
	}
	
	/*
	 * Method to pause execution for given time in seconds
	 */
	public static void waitForSeconds(int time) {
		try {
			Thread.sleep(time*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*
	 * Method to wait for page to load
	 */
	public static void waitForPageLoad() {
		try {
			new WebDriverWait(driver, 120).until(webDriver -> ((JavascriptExecutor) webDriver)
					.executeScript("return document.readyState").equals("complete"));
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Failed to wait for document to be ready");
			reportFail(e.getMessage());
		}
	}

	/*
	 * Method to select by visible text
	 */
	public static void selectByVisibleText(By objectPath, String text) {
		try {
			new WebDriverWait(driver, 30).until(ExpectedConditions.elementToBeClickable(objectPath));
			Select select = new Select(driver.findElement(objectPath));
			select.selectByVisibleText(text);
			log.info("Selected '" + text + "' from object: " + objectPath);
		} catch (Exception e) {
			reportFail("Failed to select '" + text + "' from object: " + objectPath + ", got exception: "
					+ e.getMessage());
		}

	}

	/*
	 * Method to return if an element is present or not
	 */
	public static boolean isElementClickable(By objectPath) {
		try {
			new WebDriverWait(driver, 10).until(ExpectedConditions.elementToBeClickable(objectPath));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * Method to get text of an element
	 */
	public static String getText(By objectPath) {
		try {
			new WebDriverWait(driver, 30).until(ExpectedConditions.presenceOfElementLocated(objectPath));
			return driver.findElement(objectPath).getText();
		} catch (Exception e) {
			reportFail("Unable to get text from object: " + objectPath);
			return null;
		}
	}

	/*
	 * Method to report failure
	 */
	public static void reportFail(String reportMessage) {
		System.out.println(reportMessage);
		log.error(reportMessage);
		logger.fail(reportMessage);
		Assert.fail("Test case failed: " + reportMessage);
	}

}
