package com.liberty.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.liberty.base.BaseClass;

public class ExtentReportManager extends BaseClass {

	public static ExtentReports extent;
	public static ExtentHtmlReporter htmlReporter;

	/************** Getting report instance for Extent Report ****************/
	public static ExtentReports getReportInstance() {
		if(extent==null){
			String repName = "TestReport"+ (new SimpleDateFormat("_HHmmss_ddMMyyyy")).format(new Date()) +".html";
			htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir")
					+ "/results/" + repName);
			htmlReporter.loadXMLConfig(System.getProperty("user.dir")
					+ "/externalFiles/extent-config.xml");
			extent = new ExtentReports();
			extent.attachReporter(htmlReporter);
			extent.setSystemInfo("Host name", "localhost");
			extent.setSystemInfo("Environment", "QA");
			extent.setSystemInfo("OS", "Windows 10");
			extent.setSystemInfo("Build Version", "3.141.59");
		}
		return extent;
	}
}