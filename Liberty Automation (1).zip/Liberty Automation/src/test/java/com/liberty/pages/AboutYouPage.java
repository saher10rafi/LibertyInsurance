package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

public class AboutYouPage extends BaseClass{

	private WebDriver driver;
	
	private String pageTitle = prop.getProperty("aboutYouPageTitle");
	private By firstNameTextbox = By.xpath((String) prop.get("firstNameTextbox"));
	private By lastNameTextbox = By.xpath((String) prop.get("lastNameTextbox"));
	private By monthDropdown = By.xpath((String) prop.get("monthDropdown"));
	private By dayTextbox = By.xpath((String) prop.get("dayTextbox"));
	private By yearTextbox = By.xpath((String) prop.get("yearTextbox"));
	private By emailTextbox = By.xpath((String) prop.get("emailTextbox"));
	private By nextButton = By.xpath((String) prop.get("nextButton"));
	
	
	public AboutYouPage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.LandingPage.class);
	}
	
	public void fillDetails(String fname, String lname, String month, String date, String year, String email) {
		sendText(firstNameTextbox, fname);
		sendText(lastNameTextbox, lname);
		selectByVisibleText(monthDropdown, month);
		sendText(dayTextbox, date);
		sendText(yearTextbox, year);
		sendText(emailTextbox, email);
		logger.pass("Entered details successfully");
	}
	
	public void clickNext(){
		clickOn(nextButton);
	}

	public void validatePage() {
		validatePageTitle(pageTitle);
	}
	
}
