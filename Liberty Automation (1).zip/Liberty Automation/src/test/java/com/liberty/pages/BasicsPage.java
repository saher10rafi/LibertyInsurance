package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

import junit.framework.Assert;

public class BasicsPage extends BaseClass {

	private WebDriver driver;
	
	private String pageTitle=prop.getProperty("basicsPageTitle");
	private By addressTextbox = By.xpath((String) prop.get("addressTextbox"));
	private By aptUnitTextbox = By.xpath((String) prop.get("aptUnitTextbox"));
	/*private By postalCodeTextbox = By.xpath((String) prop.get("postalCodeTextbox"));
	private By cityTextbox = By.xpath((String) prop.get("cityTextbox"));
	private By cityCode = By.xpath((String) prop.get("cityCode"));*/
	private By currentResidenceYes = By.xpath((String) prop.get("currentResidenceYes"));
	private By currentResidenceNo = By.xpath((String) prop.get("currentResidenceNo"));
	private By nextButton = By.xpath((String) prop.get("nextButton"));
	private By closeDialogButton = By.xpath("//button[contains(@class,'ButtonClose')]");
	
	public BasicsPage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.BasicsPage.class);
	}
	
	public void validatePage() {
		validatePageTitle(pageTitle);
	}
	
	public void clickNext(){
		clickOn(nextButton);
		logger.pass("Clicked on Next button successfully");
	}
	
	public void closeDialog() {
		if(isElementClickable(closeDialogButton)) {
			clickOn(closeDialogButton);
			logger.pass("Close dialog button clicked successfully");
		}
	}
	
	public void fillDetails(String address, String aptNo, String currentlyLiving) {
		sendText(addressTextbox, address);
		sendText(aptUnitTextbox, aptNo);
		if(currentlyLiving.equalsIgnoreCase("Yes"))
			clickOn(currentResidenceYes);
		else
			clickOn(currentResidenceNo);
		logger.pass("Entered basics details successfully");
	}
	
	
}
