package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

public class VehicleInfoPage extends BaseClass{

	private WebDriver driver;
	
	private String pageTitle = prop.getProperty("vehicleInfoPageTitle");
	private By vehicleSelectionYMM = By.xpath((String) prop.get("vehicleSelectionYMM"));
	private By vehicleSelectionVIN = By.xpath((String) prop.get("vehicleSelectionVIN"));
	private By vehicleYearDropdown = By.xpath((String) prop.get("vehicleYearDropdown"));
	private By vehicleMakeDropdown = By.xpath((String) prop.get("vehicleMakeDropdown"));
	private By vehicleModelDropdown = By.xpath((String) prop.get("vehicleModelDropdown"));
	private By vehicleTrimDropdown = By.xpath((String) prop.get("vehicleTrimDropdown"));
	private By bodyStyleDropdown = By.xpath((String) prop.get("bodyStyleDropdown"));
	/*private By addVehicleButton = By.xpath((String) prop.get("addVehicleButton"));*/
	private By vinTextbox = By.xpath("//input[contains(@aria-label,'VIN')]");
	private By nextButton = By.xpath((String) prop.get("nextButton"));
	
	public VehicleInfoPage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.LandingPage.class);
	}
	
	public void validatePage() {
		validatePageTitle(pageTitle);
	}
	
	public void clickNext() {
		clickOn(nextButton);
		logger.pass("Clicked on next button successfully");
	}
	
	public void fillDetails(String choice, String year, String make, String model, String trim, String bodyStyle, String vin) {
		if(choice.equalsIgnoreCase("YMM")) {
			clickOn(vehicleSelectionYMM);
			selectByVisibleText(vehicleYearDropdown, year);
			selectByVisibleText(vehicleMakeDropdown, make);
			selectByVisibleText(vehicleModelDropdown, model);
			selectByVisibleText(vehicleTrimDropdown, trim);
			selectByVisibleText(bodyStyleDropdown, bodyStyle);
		}
		else {
			clickOn(vehicleSelectionVIN);
			sendText(vinTextbox, vin);
		}
		logger.pass("Entered vehicle info details successfully");
	}

	
	
	
	
}
