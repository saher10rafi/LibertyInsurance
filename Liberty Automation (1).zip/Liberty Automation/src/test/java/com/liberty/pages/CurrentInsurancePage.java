package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

public class CurrentInsurancePage extends BaseClass {


	private WebDriver driver;
	
	private String pageTitle=prop.getProperty("currentInsurancePageTitle");
	private By insuredYes = By.xpath((String) prop.get("insuredYes"));
	private By insuredNo1 = By.xpath((String) prop.get("insuredNo1"));
	private By insuredNo2 = By.xpath((String) prop.get("insuredNo2"));
	private By hasOtherPoliciesYes = By.xpath((String) prop.get("hasOtherPoliciesYes"));
	private By hasOtherPoliciesNo = By.xpath((String) prop.get("hasOtherPoliciesNo"));
	private By policyStartDateDropdown = By.xpath((String) prop.get("policyStartDateDropdown"));
	private By nextButton = By.xpath((String) prop.get("nextButton"));
	
	
	public CurrentInsurancePage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.BasicsPage.class);
	}
	
	public void validatePage() {
		validatePageTitle(pageTitle);
	}
	
	public void clickNext(){
		clickOn(nextButton);
		logger.pass("Clicked on Next button successfully");
	}
	
	public void fillDetails(String insured, String otherPolicies, String startDate) {
		if(insured.equalsIgnoreCase("Yes"))
			clickOn(insuredYes);
		else if(insured.equalsIgnoreCase("Expired"))
			clickOn(insuredNo1);
		else
			clickOn(insuredNo2);
		if(otherPolicies.equalsIgnoreCase("Yes"))
			clickOn(hasOtherPoliciesYes);
		else
			clickOn(hasOtherPoliciesNo);
		selectByVisibleText(policyStartDateDropdown, startDate.trim());
		logger.pass("Entered current insurance details successfully");
		
	}
}
