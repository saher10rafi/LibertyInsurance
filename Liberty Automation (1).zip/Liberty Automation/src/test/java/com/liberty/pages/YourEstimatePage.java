package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

public class YourEstimatePage extends BaseClass {

	private WebDriver driver;
	
	private String pageTitle = prop.getProperty("yourEstimatePageTitle");
	private By closeDialogButton = By.xpath((String) prop.get("closeDialogButton"));
	private By estimateMessage = By.xpath((String) prop.get("estimateMessage"));
	private By estimatedPrice = By.xpath((String) prop.get("estimatedPrice"));
	private By finalizeButton = By.xpath((String) prop.get("finalizeButton"));
	private By errorMessage = By.xpath("//div[@id='error-container']//strong");
	
	public YourEstimatePage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.BasicsPage.class);
	}
	
	public void validatePage() {
		validatePageTitle(pageTitle);
	}
	
	public void closeDialog(){
		if(isElementClickable(closeDialogButton)) {
			clickOn(closeDialogButton);
			logger.pass("Closed dialog box successfully");
		}
	}
	
	public void validateEstimateMessage() {
		String estimateMsg = getText(estimateMessage);
		if(estimateMsg.contains("Your estimated price"))
			logger.pass("Estimate message validated successfully");
		else
			reportFail("Estimate message not validated successfully");
	}
	
	public void validateUnableToQuoteMessage(){
		String errorText = getText(errorMessage);
		if(errorText.contains("We're sorry, based on our underwriting guidelines* we are unable to provide you with a quote."))
			logger.pass("Error message validated successfully");
		else
			reportFail("Error message not validated successfully");
	}

	

	
}
