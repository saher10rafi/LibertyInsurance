package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

import junit.framework.Assert;

public class LandingPage extends BaseClass {

	private WebDriver driver;
	
	private String pageTitle = prop.getProperty("landingPageTitle");
	private By autoButton = By.xpath((String) prop.get("autoButton"));
	private By pincodeTextbox = By.xpath((String) prop.get("pincodeTextbox"));
	private By getMyPriceButton = By.xpath((String) prop.get("getMyPriceButton"));
	
	public LandingPage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.LandingPage.class);
	}
	
	public void validatePage() {
		validatePageTitle(pageTitle);
	}
	
	public void clickAutoButton(){
		clickOn(autoButton);
		logger.pass("Clicked on auto button");
	}
	
	public void enterPincode(String pincode){
		sendText(pincodeTextbox, pincode);
		logger.pass("Entered pincode: "+pincode);
	}

	public void clickGetMyPriceButton(){
		clickOn(getMyPriceButton);
		logger.pass("Clicked on get my price button");
	}

	
	
}
