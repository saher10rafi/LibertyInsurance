package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

public class YourVehiclePage extends BaseClass {

	private WebDriver driver;

	private String pageTitle = prop.getProperty("yourVehiclePageTitle");
	private By resourceTitle = By.xpath((String) prop.get("resourceTitle"));
	private By purchaseDateDropdown = By.xpath((String) prop.get("purchaseDateDropdown"));
	private By ownedRadio = By.xpath((String) prop.get("ownedRadio"));
	private By financedRadio = By.xpath((String) prop.get("financedRadio"));
	private By leasedRadio = By.xpath((String) prop.get("leasedRadio"));
	private By annualDistanceDropdown = By.xpath((String) prop.get("annualDistanceDropdown"));
	private By rideSharingYes = By.xpath((String) prop.get("rideSharingYes"));
	private By rideSharingNo = By.xpath((String) prop.get("rideSharingNo"));
	private By keptAtResidenceYes = By.xpath((String) prop.get("keptAtResidenceYes"));
	private By keptAtResidenceNo = By.xpath((String) prop.get("keptAtResidenceNo"));
	private By antiLockYes = By
			.xpath("//input[contains(@name,'antiLockBrakes') and @value='Four Wheel']//parent::*//label");
	private By antiLockNo = By.xpath("//input[contains(@name,'antiLockBrakes') and @value='None']//parent::*//label");
	private By nextButton = By.xpath((String) prop.get("nextButton"));

	public YourVehiclePage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.BasicsPage.class);
	}

	public void validatePage() {
		validatePageTitle(pageTitle);
	}

	public void clickNext() {
		clickOn(nextButton);
		logger.pass("Clicked on Next button successfully");
	}

	public void fillDetails(String purchaseYear, String annualDistance, String rideSharing, String keptAtResidence,
			String antiLock, String ownership) {
		if (isElementClickable(antiLockYes))
			if (antiLock.equalsIgnoreCase("Yes"))
				clickOn(antiLockYes);
			else if (isElementClickable(antiLockNo))
				if (antiLock.equalsIgnoreCase("No"))
					clickOn(antiLockNo);
		selectByVisibleText(purchaseDateDropdown, purchaseYear);
		if (isElementClickable(annualDistanceDropdown))
			selectByVisibleText(annualDistanceDropdown, annualDistance);
		if (ownership.equalsIgnoreCase("Owned"))
			clickOn(ownedRadio);
		else if (ownership.equalsIgnoreCase("Financed"))
			clickOn(financedRadio);
		else if (ownership.equalsIgnoreCase("Leased"))
			clickOn(leasedRadio);
		if (rideSharing.equalsIgnoreCase("Yes"))
			clickOn(rideSharingYes);
		else
			clickOn(rideSharingNo);
		if (keptAtResidence.equalsIgnoreCase("Yes"))
			clickOn(keptAtResidenceYes);
		else
			clickOn(keptAtResidenceNo);
	}

}
