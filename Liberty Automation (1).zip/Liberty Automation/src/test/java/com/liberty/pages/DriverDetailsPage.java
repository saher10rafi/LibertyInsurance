package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

public class DriverDetailsPage extends BaseClass {

	private WebDriver driver;

	private String pageTitle = prop.getProperty("driverDetailsPageTitle");
	private By phoneTextbox = By.xpath((String) prop.get("phoneTextbox"));
	private By licensedAgeTextbox = By.xpath((String) prop.get("licensedAgeTextbox"));
	private By residenceOwnershipDropdown = By.xpath((String) prop.get("residenceOwnershipDropdown"));
	private By hasIncedentsYes = By.xpath((String) prop.get("hasIncedentsYes"));
	private By hasIncedentsNo = By.xpath((String) prop.get("hasIncedentsNo"));
	private By avgGradeYes = By.xpath((String) prop.get("avgGradeYes"));
	private By avgGradeNo = By.xpath((String) prop.get("avgGradeNo"));
	private By courseYes = By.xpath((String) prop.get("courseYes"));
	private By courseNo = By.xpath((String) prop.get("courseNo"));
	private By nextButton = By.xpath((String) prop.get("nextButton"));

	public DriverDetailsPage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.BasicsPage.class);
	}

	public void validatePage() {
		validatePageTitle(pageTitle);
	}

	public void clickNext() {
		clickOn(nextButton);
		logger.pass("Clicked on Next button successfully");
	}

	public void fillDetails(String phonenum, String ageLicensed, String hasIncedents, String residence, String avgGrade,
			String course) {
		sendText(phoneTextbox, phonenum);
		sendText(licensedAgeTextbox, ageLicensed);
		selectByVisibleText(residenceOwnershipDropdown, residence);
		if (hasIncedents.equalsIgnoreCase("Yes"))
			clickOn(hasIncedentsYes);
		else
			clickOn(hasIncedentsNo);
		if (avgGrade.equalsIgnoreCase("Yes"))
			clickOn(avgGradeYes);
		else if (avgGrade.equalsIgnoreCase("No"))
			clickOn(avgGradeNo);
		if (course.equalsIgnoreCase("Yes"))
			clickOn(courseYes);
		else
			clickOn(courseNo);
		logger.pass("Entered additional driver details successfully");
	}
}
