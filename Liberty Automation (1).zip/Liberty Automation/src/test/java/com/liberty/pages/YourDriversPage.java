package com.liberty.pages;

import org.apache.logging.log4j.LogManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.ExtentTest;
import com.liberty.base.BaseClass;

public class YourDriversPage extends BaseClass {
	
	private WebDriver driver;
	
	private String pageTitle = prop.getProperty("yourDriversPageTitle");
	private By maleRadio = By.xpath((String) prop.get("maleRadio"));
	private By femaleRadio = By.xpath((String) prop.get("femaleRadio"));
	private By marriedRadio = By.xpath((String) prop.get("marriedRadio"));
	private By singleRadio = By.xpath((String) prop.get("singleRadio"));
	private By nextButton = By.xpath((String) prop.get("nextButton"));
	
	public YourDriversPage(WebDriver driver, ExtentTest logger) {
		this.driver = driver;
		BaseClass.logger = logger;
		BaseClass.log = LogManager.getLogger(com.liberty.pages.BasicsPage.class);
	}
	
	public void validatePage() {
		validatePageTitle(pageTitle);
	}
	
	public void clickNext(){
		clickOn(nextButton);
		logger.pass("Clicked on Next button successfully");
	}
	
	public void fillDetails(String gender, String married) {
		if(gender.equalsIgnoreCase("Female")) 
			clickOn(femaleRadio);
		else
			clickOn(maleRadio);
		if(married.equalsIgnoreCase("Yes"))
			clickOn(marriedRadio);
		else
			clickOn(singleRadio);
		logger.pass("Entered driver details successfully");
	}
	
}
