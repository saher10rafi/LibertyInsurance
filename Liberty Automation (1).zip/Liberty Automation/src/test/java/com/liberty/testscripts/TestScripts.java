package com.liberty.testscripts;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.liberty.base.BaseClass;
import com.liberty.pages.AboutYouPage;
import com.liberty.pages.BasicsPage;
import com.liberty.pages.CurrentInsurancePage;
import com.liberty.pages.DriverDetailsPage;
import com.liberty.pages.LandingPage;
import com.liberty.pages.RightTrackPage;
import com.liberty.pages.VehicleInfoPage;
import com.liberty.pages.YourDriversPage;
import com.liberty.pages.YourEstimatePage;
import com.liberty.pages.YourVehiclePage;
import com.liberty.utils.ExcelUtils;
import com.liberty.utils.ExtentReportManager;

public class TestScripts extends BaseClass {
	public static WebDriver driver;
	public Properties Prop;

	private AboutYouPage aboutYouPage;
	private BasicsPage basicsPage;
	private CurrentInsurancePage currentInsurancePage;
	private DriverDetailsPage driverDetailsPage;
	private LandingPage landingPage;
	private RightTrackPage rightTrackPage;
	private VehicleInfoPage vehicleInfoPage;
	private YourDriversPage yourDriversPage;
	private YourEstimatePage yourEstimatePage;
	private YourVehiclePage yourVehiclePage;

	@BeforeMethod
	public void startUp() {
		System.out.println("Initializing driver");
		driver = initializeDriver();
		driver.get(prop.getProperty("url"));
	}

	@Test(priority = 0, dataProvider = "autoInsuranceValidData")
	public void validDetailsTest(String testNum, String testDescription, String pincode, String address, String aptNo,
			String currentlyLiving, String firstName, String lastName, String month, String date, String year,
			String email, String addVehicleType, String model, String make, String vehicleYear, String trim,
			String bodyStyle, String vin, String antiLock, String purchaseYear, String ownership, String annualDistance,
			String rideSharing, String keptAtResidence, String rightTrack, String gender, String married, String phone,
			String ageLicensed, String ownHome, String incidents, String avgGrade, String course, String insured,
			String otherPolicies, String startDate, String getEstimate) {
		logger = ExtentReportManager.getReportInstance().createTest("Valid Data Test No " + testNum, testDescription);
		landingPage = new LandingPage(driver, logger);
		landingPage.validatePage();
		landingPage.clickAutoButton();
		landingPage.enterPincode("10002");
		landingPage.clickGetMyPriceButton();
		basicsPage = new BasicsPage(driver, logger);
		basicsPage.validatePage();
		basicsPage.closeDialog();
		basicsPage.fillDetails(address, aptNo, currentlyLiving);
		basicsPage.clickNext();
		aboutYouPage = new AboutYouPage(driver, logger);
		aboutYouPage.validatePage();
		aboutYouPage.fillDetails(firstName, lastName, month, date, year, email);
		aboutYouPage.clickNext();
		vehicleInfoPage = new VehicleInfoPage(driver, logger);
		vehicleInfoPage.validatePage();
		vehicleInfoPage.fillDetails(addVehicleType, vehicleYear, make, model, trim, bodyStyle, vin);
		vehicleInfoPage.clickNext();
		yourVehiclePage = new YourVehiclePage(driver, logger);
		yourVehiclePage.validatePage();
		yourVehiclePage.fillDetails(purchaseYear, annualDistance, rideSharing, keptAtResidence, antiLock, ownership);
		yourVehiclePage.clickNext();
		if(rightTrack.equalsIgnoreCase("Yes")) {
			rightTrackPage = new RightTrackPage(driver, logger);
			rightTrackPage.validatePage();
			rightTrackPage.signUp(rightTrack);
			rightTrackPage.clickNext();
		}
		yourDriversPage = new YourDriversPage(driver, logger);
		yourDriversPage.validatePage();
		yourDriversPage.fillDetails(gender, married);
		yourDriversPage.clickNext();
		driverDetailsPage = new DriverDetailsPage(driver, logger);
		driverDetailsPage.validatePage();
		driverDetailsPage.fillDetails(phone, ageLicensed, incidents, ownHome, avgGrade, course);
		driverDetailsPage.clickNext();
		currentInsurancePage = new CurrentInsurancePage(driver, logger);
		currentInsurancePage.validatePage();
		currentInsurancePage.fillDetails(insured, otherPolicies, startDate);
		currentInsurancePage.clickNext();
		yourEstimatePage = new YourEstimatePage(driver, logger);
		yourEstimatePage.validatePage();
		if (getEstimate.equalsIgnoreCase("Yes"))
			yourEstimatePage.validateEstimateMessage();
		else
			yourEstimatePage.validateUnableToQuoteMessage();

	}

	@AfterMethod
	public void tearDown() {
		System.out.println("Closing Browser");
		driver.quit();
	}

	@AfterSuite
	public void afterSuite(){
		ExtentReportManager.getReportInstance().flush();
	}
	
	@DataProvider
	public Object[][] autoInsuranceValidData() throws IOException {
		HashMap<String, ArrayList<String>> dataMap = ExcelUtils.readExcelData("validDetailsTests");
		int noRow = dataMap.size();
		int noCol = dataMap.get("1").size();
		Object[][] data = new Object[noRow][noCol];
		for (int i = 0; i < noRow; ++i) {
			ArrayList<String> rowData = dataMap.get("" + (i + 1));
			for (int j = 0; j < noCol; ++j) {
				data[i][j] = rowData.get(j);
			}
		}
		return data;
	}

}
